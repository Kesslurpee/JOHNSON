﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS
{
    public partial class PRODUCT : Form
    {
        SqlConnection connection = new SqlConnection();
        SqlCommand command = new SqlCommand();
        DatabaseC dbcon = new DatabaseC();
        SqlDataReader dr;
        public PRODUCT()
        {
            InitializeComponent();
            connection = new SqlConnection(dbcon.myConnection());
            LoadProduct();
        }

        public void LoadProduct()
        {
            int i = 0;
            dataGridViewProduct.Rows.Clear();
            command = new SqlCommand("SELECT p.prodcode, p.barcode, p.proddesc, b.brand, c.category, p.price, p.reorder FROM tbProduct AS p INNER JOIN tbBrand AS b ON b.id = p.bid INNER JOIN tbCategory AS c on c.id = p.cid WHERE CONCAT(p.proddesc, b.brand, c.category) LIKE '%" + metroTextBoxSearch.Text + "%'", connection);
            connection.Open();
            dr = command.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataGridViewProduct.Rows.Add(i, dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(), dr[4].ToString(), dr[5].ToString(), dr[6].ToString());
            }
            dr.Close();
            connection.Close();

        }

        private void PRODUCT_Load(object sender, EventArgs e)
        {

        }

        private void Add_Click(object sender, EventArgs e)
        {
            PRODUCTMODULE pm = new PRODUCTMODULE(this);
            pm.ShowDialog();
        }

        private void dataGridViewProduct_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string ColumnName = dataGridViewProduct.Columns[e.ColumnIndex].Name;
            if (ColumnName == "Edit")
            {
                PRODUCTMODULE prodMOD = new PRODUCTMODULE(this);
                prodMOD.textBoxProdCode.Text = dataGridViewProduct.Rows[e.RowIndex].Cells[1].Value.ToString();
                prodMOD.textBoxBarCode.Text = dataGridViewProduct.Rows[e.RowIndex].Cells[2].Value.ToString();
                prodMOD.textBoxDescription.Text = dataGridViewProduct.Rows[e.RowIndex].Cells[3].Value.ToString();
                prodMOD.comboBoxBrand.Text = dataGridViewProduct.Rows[e.RowIndex].Cells[4].Value.ToString();
                prodMOD.comboBoxCategory.Text = dataGridViewProduct.Rows[e.RowIndex].Cells[5].Value.ToString();
                prodMOD.textBoxPrice.Text = dataGridViewProduct.Rows[e.RowIndex].Cells[6].Value.ToString();
                prodMOD.numericUpDownReOrder.Value = int.Parse(dataGridViewProduct.Rows[e.RowIndex].Cells[7].Value.ToString());

                prodMOD.textBoxProdCode.Enabled = false;
                prodMOD.Save.Enabled = false;  
                prodMOD.Update.Enabled = true;
                prodMOD.ShowDialog();


            } 
            else  if(ColumnName == "Delete")
                {

                    if (MessageBox.Show("Are you sure you want to delete this product?", "Delete Product", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        connection.Open();
                        command = new SqlCommand("DELETE FROM tbProduct WHERE prodcode LIKE '" + dataGridViewProduct[1, e.RowIndex].Value.ToString() + "'", connection);
                        command.ExecuteNonQuery();
                        connection.Close();
                        MessageBox.Show("Product has been successfully deleted!", "Point Of Sales", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                LoadProduct();
            }
            
        }
        
        private void metroTextBoxSearch_TextChanged(object sender, EventArgs e)
        {
            LoadProduct();
        }
    }
    }


