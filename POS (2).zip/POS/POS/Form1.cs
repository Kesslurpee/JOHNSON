﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Common;

namespace POS
{
    public partial class Form1 : Form
    {
        SqlConnection connection = new SqlConnection();
        SqlCommand command = new SqlCommand();
        DatabaseC dbcon = new DatabaseC();
        public Form1()
        {
            InitializeComponent();
            CustomDesigning();
            connection = new SqlConnection(dbcon.myConnection());
            connection.Open();
           
        }
        #region panelMain

        private void CustomDesigning()
        {
            panelSubProd.Visible = false;
            panelSubRec.Visible = false;
            panelSubStock.Visible = false;
            SubSettings.Visible = false;
        }

        private void HideSubMenu()
        {
            if(panelSubProd.Visible == true) 
                panelSubProd.Visible = false;
            if (panelSubRec.Visible == true)
                panelSubRec.Visible = false;
            if (panelSubStock.Visible == true)
                panelSubStock.Visible = false;
            if (SubSettings.Visible == true)
                SubSettings.Visible = false;

        }
        private void ShowSubMenu(Panel submenu)
        {
            if(submenu.Visible == false)
            {
                HideSubMenu();
                submenu.Visible = true;
            }
            else
                submenu.Visible = false;
        }
        
        
       

        private void HideMenu()
        {
            if(panelSubProd.Visible == true)
                panelSubProd.Visible = false;

            if (panelSubRec.Visible == true)
                panelSubRec.Visible = false;

            if (panelSubStock.Visible == true)
                panelSubStock.Visible = false;
            
            if (SubSettings.Visible == true)
                SubSettings.Visible = false;

        }

        private void showMenu(Panel submenu) 
        {
            if (submenu.Visible == false)
            {
                HideMenu();
                submenu.Visible = true;
            }
            else
                submenu.Visible = false;    
        }
        #endregion panelMain
        private Form actForm = null;
        public void openChildForm(Form cf)
        {
            if (actForm != null)
                actForm.Close();
            actForm = cf;
            cf.TopLevel = false;
            cf.FormBorderStyle = FormBorderStyle.None;  
            cf.Dock = DockStyle.Fill;
            Title.Text = cf.Text;
            panelMain.Controls.Add(cf);
            panelMain.Tag = cf;
            cf.BringToFront();
            cf.Show();
        }
        private void Title_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnDash_Click(object sender, EventArgs e)
        {

        }

        private void btnProd_Click(object sender, EventArgs e)
        {
            showMenu(panelSubProd);
        }

        private void ProdL_Click(object sender, EventArgs e)
        {
            openChildForm(new PRODUCT());
            HideMenu();
        }

        private void Cat_Click(object sender, EventArgs e)
        {
            openChildForm(new CATEGORY());
            HideMenu();
        }

        private void Brand_Click(object sender, EventArgs e)
        {
            openChildForm(new BRAND());
            HideMenu();

        }

        private void InStock_Click(object sender, EventArgs e)
        {
            showMenu(panelSubStock);
        }

        private void StockEnt_Click(object sender, EventArgs e)
        {
            HideMenu();
        }

        private void StockAdj_Click(object sender, EventArgs e)
        {
            HideMenu();
        }

        private void Supplier_Click(object sender, EventArgs e)
        {
            openChildForm(new SUPPLIER());  
            HideMenu();
        }

        private void Record_Click(object sender, EventArgs e)
        {
            showMenu(panelSubRec);
        }

        private void SaleHis_Click(object sender, EventArgs e)
        {
            HideMenu();
        }

        private void POSAdj_Click(object sender, EventArgs e)
        {
            HideMenu();
        }

        private void Setting_Click(object sender, EventArgs e)
        {
            showMenu(SubSettings);
        }

        private void User_Click(object sender, EventArgs e)
        {
            openChildForm(new ACCOUNT());
            HideMenu();
        }

        private void Store_Click(object sender, EventArgs e)
        {
            HideMenu();
        }

        private void Logout_Click(object sender, EventArgs e)
        {
            HideMenu();
        }

        private void panelMain_Paint(object sender, PaintEventArgs e)
        {
 
        }

        private void panelSettings_Paint(object sender, PaintEventArgs e)
        {

        }

        private void SubSettings_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panelSubRec_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panelSubStock_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panelSubProd_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Username_Click(object sender, EventArgs e)
        {

        }

        private void Role_Click(object sender, EventArgs e)
        {

        }

        private void panelTitle_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panelLogo_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
