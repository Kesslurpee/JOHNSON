﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS
{
    public partial class PRODUCTMODULE : Form
    {
        SqlConnection connection = new SqlConnection();
        SqlCommand command = new SqlCommand();
        DatabaseC dbcon = new DatabaseC();
        string title = "Point of Sales";
        PRODUCT prod;
        public PRODUCTMODULE(PRODUCT p)
        {
            InitializeComponent();
            connection = new SqlConnection(dbcon.myConnection());
            prod = p;
            LoadBrand();
            LoadCategory();
        }

        public void LoadCategory()
        {
            comboBoxCategory.Items.Clear();
            comboBoxCategory.DataSource = dbcon.getTable("SELECT * FROM tbCategory");
            comboBoxCategory.DisplayMember = "category";
            comboBoxCategory.ValueMember = "id";

        }

        public void LoadBrand()
        {
            comboBoxBrand.Items.Clear();
            comboBoxBrand.DataSource = dbcon.getTable("SELECT * FROM tbBrand");
            comboBoxBrand.DisplayMember = "brand";
            comboBoxBrand.ValueMember = "id";
            
        }

        private void Close_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
        
        public void Clear()
        {
            textBoxProdCode.Clear();
            textBoxBarCode.Clear();
            textBoxDescription.Clear();
            textBoxPrice.Clear();
            comboBoxBrand.SelectedIndex = 0;
            comboBoxCategory.SelectedIndex = 0;
            numericUpDownReOrder.Value = 1;

            textBoxProdCode.Enabled = true;
            textBoxProdCode.Focus();
            Save.Enabled = true;    
            Update.Enabled = false;
        }

        private void Save_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Are you sure you want to save this product?", "Save Product", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    command = new SqlCommand("INSERT INTO tbProduct(prodcode, barcode, bid, proddesc, cid, price, reorder) VALUES (@prodcode, @barcode, @bid, @proddesc, @cid, @price, @reorder)", connection);
                    command.Parameters.AddWithValue("@prodcode", textBoxProdCode.Text);    
                    command.Parameters.AddWithValue("@barcode", textBoxBarCode.Text);
                    command.Parameters.AddWithValue("@bid", comboBoxBrand.SelectedValue);
                    command.Parameters.AddWithValue("proddesc", textBoxDescription.Text);
                    command.Parameters.AddWithValue("@cid", comboBoxCategory.SelectedValue);
                    command.Parameters.AddWithValue("@price", double.Parse(textBoxPrice.Text));
                    command.Parameters.AddWithValue("@reorder", numericUpDownReOrder.Value);
                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                    MessageBox.Show("Product has been successfully saved!", title);
                    Clear();
                    prod.LoadProduct();
                }
            }
            catch (Exception ex)            
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void Update_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Are you sure you want to update this product?", "Update Product", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    command = new SqlCommand("UPDATE tbProduct SET barcode=@barcode, proddesc=@proddesc, bid=@bid, cid=@cid, price=@price, reorder=@reorder WHERE prodcode LIKE @prodcode", connection);
                    command.Parameters.AddWithValue("@prodcode", textBoxProdCode.Text);
                    command.Parameters.AddWithValue("@barcode", textBoxBarCode.Text);
                    command.Parameters.AddWithValue("@bid", comboBoxBrand.SelectedValue);
                    command.Parameters.AddWithValue("proddesc", textBoxDescription.Text);
                    command.Parameters.AddWithValue("@cid", comboBoxCategory.SelectedValue);
                    command.Parameters.AddWithValue("@price", double.Parse(textBoxPrice.Text));
                    command.Parameters.AddWithValue("@reorder", numericUpDownReOrder.Value);
                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                    MessageBox.Show("Product has been successfully updated!", title);
                    Clear();
                    this.Dispose();
                }

            }
            catch (Exception ex)
            {


                MessageBox.Show(ex.Message);
            }
        }

        private void PRODUCTMODULE_Load(object sender, EventArgs e)
        {

        }
    }
}


