﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS
{
    public partial class PAYMENT : Form
    {
        SqlConnection connection = new SqlConnection();
        SqlCommand command = new SqlCommand();
        DatabaseC dbcon = new DatabaseC();
        SqlDataReader dr;
        public PAYMENT()
        {
            InitializeComponent();
            connection = new SqlConnection(dbcon.myConnection());
        }

        private void PAYMENT_Load(object sender, EventArgs e)
        {

        }

        private void textBoxCash_TextChanged(object sender, EventArgs e)
        {
            try
            {
                double sale = double.Parse(textBoxSale.Text);
                double cash = double.Parse(textBoxCash.Text);
                double charge = cash - sale;
                textBoxChange.Text = charge.ToString("#,##0.00");
            }
            catch (Exception)
            {
                textBoxChange.Text = "0.00";
            }
        }

        private void textBoxSale_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxChange_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonOne_Click(object sender, EventArgs e)
        {
            textBoxCash.Text += buttonOne.Text;
        }

        private void buttonTwo_Click(object sender, EventArgs e)
        {
            textBoxCash.Text += buttonTwo.Text;
        }

        private void buttonThree_Click(object sender, EventArgs e)
        {
            textBoxCash.Text += buttonThree.Text;
        }

        private void buttonFour_Click(object sender, EventArgs e)
        {
            textBoxCash.Text += buttonFour.Text;
        }

        private void buttonFive_Click(object sender, EventArgs e)
        {
            textBoxCash.Text += buttonFive.Text;
        }

        private void buttonSix_Click(object sender, EventArgs e)
        {
            textBoxCash.Text += buttonSix.Text;
        }

        private void buttonSeven_Click(object sender, EventArgs e)
        {
            textBoxCash.Text += buttonSeven.Text;
        }

        private void buttonEight_Click(object sender, EventArgs e)
        {
            textBoxCash.Text += buttonEight.Text;
        }

        private void buttonNine_Click(object sender, EventArgs e)
        {
            textBoxCash.Text += buttonNine.Text;
        }

        private void buttonZeroZero_Click(object sender, EventArgs e)
        {
            textBoxCash.Text += buttonZeroZero.Text;
        }

        private void buttonZero_Click(object sender, EventArgs e)
        {
            textBoxCash.Text += buttonZero.Text;
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxCash.Clear();
            textBoxCash.Focus();
        }

        private void buttonEnter_Click(object sender, EventArgs e)
        {

        }

        private void PAYMENT_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) this.Dispose();
            else if (e.KeyCode == Keys.Enter) buttonEnter.PerformClick();
            
        }
    }
}
