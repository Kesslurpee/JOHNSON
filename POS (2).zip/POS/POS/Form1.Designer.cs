﻿namespace POS
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panelSettings = new System.Windows.Forms.Panel();
            this.Logout = new System.Windows.Forms.Button();
            this.SubSettings = new System.Windows.Forms.Panel();
            this.Store = new System.Windows.Forms.Button();
            this.User = new System.Windows.Forms.Button();
            this.Setting = new System.Windows.Forms.Button();
            this.panelSubRec = new System.Windows.Forms.Panel();
            this.POSAdj = new System.Windows.Forms.Button();
            this.SaleHis = new System.Windows.Forms.Button();
            this.Record = new System.Windows.Forms.Button();
            this.Supplier = new System.Windows.Forms.Button();
            this.panelSubStock = new System.Windows.Forms.Panel();
            this.StockAdj = new System.Windows.Forms.Button();
            this.StockEnt = new System.Windows.Forms.Button();
            this.InStock = new System.Windows.Forms.Button();
            this.panelSubProd = new System.Windows.Forms.Panel();
            this.Brand = new System.Windows.Forms.Button();
            this.Cat = new System.Windows.Forms.Button();
            this.ProdL = new System.Windows.Forms.Button();
            this.btnProd = new System.Windows.Forms.Button();
            this.btnDash = new System.Windows.Forms.Button();
            this.panelLogo = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.Username = new System.Windows.Forms.Label();
            this.Role = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelTitle = new System.Windows.Forms.Panel();
            this.panelMain = new System.Windows.Forms.Panel();
            this.Title = new System.Windows.Forms.Label();
            this.panelSettings.SuspendLayout();
            this.SubSettings.SuspendLayout();
            this.panelSubRec.SuspendLayout();
            this.panelSubStock.SuspendLayout();
            this.panelSubProd.SuspendLayout();
            this.panelLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panelTitle.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelSettings
            // 
            this.panelSettings.AutoScroll = true;
            this.panelSettings.Controls.Add(this.Logout);
            this.panelSettings.Controls.Add(this.SubSettings);
            this.panelSettings.Controls.Add(this.Setting);
            this.panelSettings.Controls.Add(this.panelSubRec);
            this.panelSettings.Controls.Add(this.Record);
            this.panelSettings.Controls.Add(this.Supplier);
            this.panelSettings.Controls.Add(this.panelSubStock);
            this.panelSettings.Controls.Add(this.InStock);
            this.panelSettings.Controls.Add(this.panelSubProd);
            this.panelSettings.Controls.Add(this.btnProd);
            this.panelSettings.Controls.Add(this.btnDash);
            this.panelSettings.Controls.Add(this.panelLogo);
            this.panelSettings.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.panelSettings.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelSettings.Location = new System.Drawing.Point(0, 0);
            this.panelSettings.Name = "panelSettings";
            this.panelSettings.Size = new System.Drawing.Size(200, 498);
            this.panelSettings.TabIndex = 0;
            this.panelSettings.Paint += new System.Windows.Forms.PaintEventHandler(this.panelSettings_Paint);
            // 
            // Logout
            // 
            this.Logout.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Logout.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.Logout.FlatAppearance.BorderSize = 0;
            this.Logout.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Logout.ForeColor = System.Drawing.Color.White;
            this.Logout.Image = ((System.Drawing.Image)(resources.GetObject("Logout.Image")));
            this.Logout.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.Logout.Location = new System.Drawing.Point(0, 845);
            this.Logout.Name = "Logout";
            this.Logout.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.Logout.Size = new System.Drawing.Size(183, 45);
            this.Logout.TabIndex = 9;
            this.Logout.Text = "Logout";
            this.Logout.UseVisualStyleBackColor = true;
            this.Logout.Click += new System.EventHandler(this.Logout_Click);
            // 
            // SubSettings
            // 
            this.SubSettings.Controls.Add(this.Store);
            this.SubSettings.Controls.Add(this.User);
            this.SubSettings.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.SubSettings.Dock = System.Windows.Forms.DockStyle.Top;
            this.SubSettings.Location = new System.Drawing.Point(0, 755);
            this.SubSettings.Name = "SubSettings";
            this.SubSettings.Size = new System.Drawing.Size(183, 90);
            this.SubSettings.TabIndex = 8;
            this.SubSettings.Paint += new System.Windows.Forms.PaintEventHandler(this.SubSettings_Paint);
            // 
            // Store
            // 
            this.Store.BackColor = System.Drawing.Color.Firebrick;
            this.Store.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Store.Dock = System.Windows.Forms.DockStyle.Top;
            this.Store.FlatAppearance.BorderSize = 0;
            this.Store.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Store.ForeColor = System.Drawing.Color.White;
            this.Store.Location = new System.Drawing.Point(0, 45);
            this.Store.Name = "Store";
            this.Store.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.Store.Size = new System.Drawing.Size(183, 45);
            this.Store.TabIndex = 5;
            this.Store.Text = "Store";
            this.Store.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Store.UseVisualStyleBackColor = false;
            this.Store.Click += new System.EventHandler(this.Store_Click);
            // 
            // User
            // 
            this.User.BackColor = System.Drawing.Color.Firebrick;
            this.User.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.User.Dock = System.Windows.Forms.DockStyle.Top;
            this.User.FlatAppearance.BorderSize = 0;
            this.User.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.User.ForeColor = System.Drawing.Color.White;
            this.User.Location = new System.Drawing.Point(0, 0);
            this.User.Name = "User";
            this.User.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.User.Size = new System.Drawing.Size(183, 45);
            this.User.TabIndex = 4;
            this.User.Text = "User";
            this.User.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.User.UseVisualStyleBackColor = false;
            this.User.Click += new System.EventHandler(this.User_Click);
            // 
            // Setting
            // 
            this.Setting.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Setting.Dock = System.Windows.Forms.DockStyle.Top;
            this.Setting.FlatAppearance.BorderSize = 0;
            this.Setting.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Setting.ForeColor = System.Drawing.Color.White;
            this.Setting.Image = ((System.Drawing.Image)(resources.GetObject("Setting.Image")));
            this.Setting.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.Setting.Location = new System.Drawing.Point(0, 710);
            this.Setting.Name = "Setting";
            this.Setting.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.Setting.Size = new System.Drawing.Size(183, 45);
            this.Setting.TabIndex = 7;
            this.Setting.Text = "Settings";
            this.Setting.UseVisualStyleBackColor = true;
            this.Setting.Click += new System.EventHandler(this.Setting_Click);
            // 
            // panelSubRec
            // 
            this.panelSubRec.Controls.Add(this.POSAdj);
            this.panelSubRec.Controls.Add(this.SaleHis);
            this.panelSubRec.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.panelSubRec.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSubRec.Location = new System.Drawing.Point(0, 620);
            this.panelSubRec.Name = "panelSubRec";
            this.panelSubRec.Size = new System.Drawing.Size(183, 90);
            this.panelSubRec.TabIndex = 6;
            this.panelSubRec.Paint += new System.Windows.Forms.PaintEventHandler(this.panelSubRec_Paint);
            // 
            // POSAdj
            // 
            this.POSAdj.BackColor = System.Drawing.Color.Firebrick;
            this.POSAdj.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.POSAdj.Dock = System.Windows.Forms.DockStyle.Top;
            this.POSAdj.FlatAppearance.BorderSize = 0;
            this.POSAdj.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.POSAdj.ForeColor = System.Drawing.Color.White;
            this.POSAdj.Location = new System.Drawing.Point(0, 45);
            this.POSAdj.Name = "POSAdj";
            this.POSAdj.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.POSAdj.Size = new System.Drawing.Size(183, 45);
            this.POSAdj.TabIndex = 5;
            this.POSAdj.Text = "POS Adjustment";
            this.POSAdj.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.POSAdj.UseVisualStyleBackColor = false;
            this.POSAdj.Click += new System.EventHandler(this.POSAdj_Click);
            // 
            // SaleHis
            // 
            this.SaleHis.BackColor = System.Drawing.Color.Firebrick;
            this.SaleHis.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.SaleHis.Dock = System.Windows.Forms.DockStyle.Top;
            this.SaleHis.FlatAppearance.BorderSize = 0;
            this.SaleHis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SaleHis.ForeColor = System.Drawing.Color.White;
            this.SaleHis.Location = new System.Drawing.Point(0, 0);
            this.SaleHis.Name = "SaleHis";
            this.SaleHis.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.SaleHis.Size = new System.Drawing.Size(183, 45);
            this.SaleHis.TabIndex = 4;
            this.SaleHis.Text = "Sale History";
            this.SaleHis.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SaleHis.UseVisualStyleBackColor = false;
            this.SaleHis.Click += new System.EventHandler(this.SaleHis_Click);
            // 
            // Record
            // 
            this.Record.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Record.Dock = System.Windows.Forms.DockStyle.Top;
            this.Record.FlatAppearance.BorderSize = 0;
            this.Record.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Record.ForeColor = System.Drawing.Color.White;
            this.Record.Image = ((System.Drawing.Image)(resources.GetObject("Record.Image")));
            this.Record.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.Record.Location = new System.Drawing.Point(0, 575);
            this.Record.Name = "Record";
            this.Record.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.Record.Size = new System.Drawing.Size(183, 45);
            this.Record.TabIndex = 5;
            this.Record.Text = "Record";
            this.Record.UseVisualStyleBackColor = true;
            this.Record.Click += new System.EventHandler(this.Record_Click);
            // 
            // Supplier
            // 
            this.Supplier.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Supplier.Dock = System.Windows.Forms.DockStyle.Top;
            this.Supplier.FlatAppearance.BorderSize = 0;
            this.Supplier.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Supplier.ForeColor = System.Drawing.Color.White;
            this.Supplier.Image = ((System.Drawing.Image)(resources.GetObject("Supplier.Image")));
            this.Supplier.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.Supplier.Location = new System.Drawing.Point(0, 530);
            this.Supplier.Name = "Supplier";
            this.Supplier.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.Supplier.Size = new System.Drawing.Size(183, 45);
            this.Supplier.TabIndex = 4;
            this.Supplier.Text = "Supplier";
            this.Supplier.UseVisualStyleBackColor = true;
            this.Supplier.Click += new System.EventHandler(this.Supplier_Click);
            // 
            // panelSubStock
            // 
            this.panelSubStock.Controls.Add(this.StockAdj);
            this.panelSubStock.Controls.Add(this.StockEnt);
            this.panelSubStock.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.panelSubStock.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSubStock.Location = new System.Drawing.Point(0, 440);
            this.panelSubStock.Name = "panelSubStock";
            this.panelSubStock.Size = new System.Drawing.Size(183, 90);
            this.panelSubStock.TabIndex = 0;
            this.panelSubStock.Paint += new System.Windows.Forms.PaintEventHandler(this.panelSubStock_Paint);
            // 
            // StockAdj
            // 
            this.StockAdj.BackColor = System.Drawing.Color.Firebrick;
            this.StockAdj.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.StockAdj.Dock = System.Windows.Forms.DockStyle.Top;
            this.StockAdj.FlatAppearance.BorderSize = 0;
            this.StockAdj.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.StockAdj.ForeColor = System.Drawing.Color.White;
            this.StockAdj.Location = new System.Drawing.Point(0, 45);
            this.StockAdj.Name = "StockAdj";
            this.StockAdj.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.StockAdj.Size = new System.Drawing.Size(183, 45);
            this.StockAdj.TabIndex = 5;
            this.StockAdj.Text = "Stock Adjustment";
            this.StockAdj.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.StockAdj.UseVisualStyleBackColor = false;
            this.StockAdj.Click += new System.EventHandler(this.StockAdj_Click);
            // 
            // StockEnt
            // 
            this.StockEnt.BackColor = System.Drawing.Color.Firebrick;
            this.StockEnt.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.StockEnt.Dock = System.Windows.Forms.DockStyle.Top;
            this.StockEnt.FlatAppearance.BorderSize = 0;
            this.StockEnt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.StockEnt.ForeColor = System.Drawing.Color.White;
            this.StockEnt.Location = new System.Drawing.Point(0, 0);
            this.StockEnt.Name = "StockEnt";
            this.StockEnt.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.StockEnt.Size = new System.Drawing.Size(183, 45);
            this.StockEnt.TabIndex = 4;
            this.StockEnt.Text = "Stock Entry";
            this.StockEnt.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.StockEnt.UseVisualStyleBackColor = false;
            this.StockEnt.Click += new System.EventHandler(this.StockEnt_Click);
            // 
            // InStock
            // 
            this.InStock.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.InStock.Dock = System.Windows.Forms.DockStyle.Top;
            this.InStock.FlatAppearance.BorderSize = 0;
            this.InStock.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.InStock.ForeColor = System.Drawing.Color.White;
            this.InStock.Image = ((System.Drawing.Image)(resources.GetObject("InStock.Image")));
            this.InStock.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.InStock.Location = new System.Drawing.Point(0, 395);
            this.InStock.Name = "InStock";
            this.InStock.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.InStock.Size = new System.Drawing.Size(183, 45);
            this.InStock.TabIndex = 3;
            this.InStock.Text = "In Stock";
            this.InStock.UseVisualStyleBackColor = true;
            this.InStock.Click += new System.EventHandler(this.InStock_Click);
            // 
            // panelSubProd
            // 
            this.panelSubProd.BackColor = System.Drawing.Color.Firebrick;
            this.panelSubProd.Controls.Add(this.Brand);
            this.panelSubProd.Controls.Add(this.Cat);
            this.panelSubProd.Controls.Add(this.ProdL);
            this.panelSubProd.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.panelSubProd.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSubProd.Location = new System.Drawing.Point(0, 260);
            this.panelSubProd.Name = "panelSubProd";
            this.panelSubProd.Size = new System.Drawing.Size(183, 135);
            this.panelSubProd.TabIndex = 0;
            this.panelSubProd.UseWaitCursor = true;
            this.panelSubProd.Paint += new System.Windows.Forms.PaintEventHandler(this.panelSubProd_Paint);
            // 
            // Brand
            // 
            this.Brand.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.Brand.Dock = System.Windows.Forms.DockStyle.Top;
            this.Brand.FlatAppearance.BorderSize = 0;
            this.Brand.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Brand.ForeColor = System.Drawing.Color.White;
            this.Brand.Location = new System.Drawing.Point(0, 90);
            this.Brand.Name = "Brand";
            this.Brand.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.Brand.Size = new System.Drawing.Size(183, 45);
            this.Brand.TabIndex = 5;
            this.Brand.Text = "BRAND";
            this.Brand.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Brand.UseVisualStyleBackColor = true;
            this.Brand.UseWaitCursor = true;
            this.Brand.Click += new System.EventHandler(this.Brand_Click);
            // 
            // Cat
            // 
            this.Cat.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.Cat.Dock = System.Windows.Forms.DockStyle.Top;
            this.Cat.FlatAppearance.BorderSize = 0;
            this.Cat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Cat.ForeColor = System.Drawing.Color.White;
            this.Cat.Location = new System.Drawing.Point(0, 45);
            this.Cat.Name = "Cat";
            this.Cat.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.Cat.Size = new System.Drawing.Size(183, 45);
            this.Cat.TabIndex = 4;
            this.Cat.Text = "CATEGORY";
            this.Cat.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Cat.UseVisualStyleBackColor = true;
            this.Cat.UseWaitCursor = true;
            this.Cat.Click += new System.EventHandler(this.Cat_Click);
            // 
            // ProdL
            // 
            this.ProdL.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.ProdL.Dock = System.Windows.Forms.DockStyle.Top;
            this.ProdL.FlatAppearance.BorderSize = 0;
            this.ProdL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ProdL.ForeColor = System.Drawing.Color.White;
            this.ProdL.Location = new System.Drawing.Point(0, 0);
            this.ProdL.Name = "ProdL";
            this.ProdL.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.ProdL.Size = new System.Drawing.Size(183, 45);
            this.ProdL.TabIndex = 3;
            this.ProdL.Text = "PRODUCT LIST";
            this.ProdL.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ProdL.UseVisualStyleBackColor = true;
            this.ProdL.UseWaitCursor = true;
            this.ProdL.Click += new System.EventHandler(this.ProdL_Click);
            // 
            // btnProd
            // 
            this.btnProd.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btnProd.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnProd.FlatAppearance.BorderSize = 0;
            this.btnProd.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnProd.ForeColor = System.Drawing.Color.White;
            this.btnProd.Image = ((System.Drawing.Image)(resources.GetObject("btnProd.Image")));
            this.btnProd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnProd.Location = new System.Drawing.Point(0, 215);
            this.btnProd.Name = "btnProd";
            this.btnProd.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.btnProd.Size = new System.Drawing.Size(183, 45);
            this.btnProd.TabIndex = 2;
            this.btnProd.Text = "PRODUCT";
            this.btnProd.UseVisualStyleBackColor = true;
            this.btnProd.Click += new System.EventHandler(this.btnProd_Click);
            // 
            // btnDash
            // 
            this.btnDash.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btnDash.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnDash.FlatAppearance.BorderSize = 0;
            this.btnDash.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDash.ForeColor = System.Drawing.Color.White;
            this.btnDash.Image = ((System.Drawing.Image)(resources.GetObject("btnDash.Image")));
            this.btnDash.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDash.Location = new System.Drawing.Point(0, 170);
            this.btnDash.Name = "btnDash";
            this.btnDash.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.btnDash.Size = new System.Drawing.Size(183, 45);
            this.btnDash.TabIndex = 0;
            this.btnDash.Text = "DASHBOARD";
            this.btnDash.UseVisualStyleBackColor = true;
            this.btnDash.Click += new System.EventHandler(this.btnDash_Click);
            // 
            // panelLogo
            // 
            this.panelLogo.Controls.Add(this.label1);
            this.panelLogo.Controls.Add(this.Username);
            this.panelLogo.Controls.Add(this.Role);
            this.panelLogo.Controls.Add(this.pictureBox1);
            this.panelLogo.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.panelLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLogo.Location = new System.Drawing.Point(0, 0);
            this.panelLogo.Name = "panelLogo";
            this.panelLogo.Size = new System.Drawing.Size(183, 170);
            this.panelLogo.TabIndex = 1;
            this.panelLogo.Paint += new System.Windows.Forms.PaintEventHandler(this.panelLogo_Paint);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(3, 120);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(24, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Ln";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Username
            // 
            this.Username.AutoSize = true;
            this.Username.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Username.ForeColor = System.Drawing.Color.White;
            this.Username.Location = new System.Drawing.Point(52, 120);
            this.Username.Name = "Username";
            this.Username.Size = new System.Drawing.Size(76, 17);
            this.Username.TabIndex = 0;
            this.Username.Text = "Username";
            this.Username.Click += new System.EventHandler(this.Username_Click);
            // 
            // Role
            // 
            this.Role.AutoSize = true;
            this.Role.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Role.ForeColor = System.Drawing.Color.White;
            this.Role.Location = new System.Drawing.Point(64, 150);
            this.Role.Name = "Role";
            this.Role.Size = new System.Drawing.Size(49, 17);
            this.Role.TabIndex = 0;
            this.Role.Text = "Admin";
            this.Role.Click += new System.EventHandler(this.Role_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(183, 114);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // panelTitle
            // 
            this.panelTitle.BackColor = System.Drawing.Color.White;
            this.panelTitle.Controls.Add(this.Title);
            this.panelTitle.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.panelTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTitle.Location = new System.Drawing.Point(200, 0);
            this.panelTitle.Name = "panelTitle";
            this.panelTitle.Size = new System.Drawing.Size(984, 170);
            this.panelTitle.TabIndex = 1;
            this.panelTitle.Paint += new System.Windows.Forms.PaintEventHandler(this.panelTitle_Paint);
            // 
            // panelMain
            // 
            this.panelMain.BackColor = System.Drawing.Color.White;
            this.panelMain.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panelMain.BackgroundImage")));
            this.panelMain.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.panelMain.Location = new System.Drawing.Point(200, 103);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(984, 395);
            this.panelMain.TabIndex = 2;
            this.panelMain.Paint += new System.Windows.Forms.PaintEventHandler(this.panelMain_Paint);
            // 
            // Title
            // 
            this.Title.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Title.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Title.ForeColor = System.Drawing.Color.White;
            this.Title.Image = ((System.Drawing.Image)(resources.GetObject("Title.Image")));
            this.Title.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Title.Location = new System.Drawing.Point(214, 0);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(505, 105);
            this.Title.TabIndex = 3;
            this.Title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Title.Click += new System.EventHandler(this.Title_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(1184, 498);
            this.Controls.Add(this.panelMain);
            this.Controls.Add(this.panelTitle);
            this.Controls.Add(this.panelSettings);
            this.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Point of Sales";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panelSettings.ResumeLayout(false);
            this.SubSettings.ResumeLayout(false);
            this.panelSubRec.ResumeLayout(false);
            this.panelSubStock.ResumeLayout(false);
            this.panelSubProd.ResumeLayout(false);
            this.panelLogo.ResumeLayout(false);
            this.panelLogo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panelTitle.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelSettings;
        private System.Windows.Forms.Panel panelLogo;
        private System.Windows.Forms.Panel panelTitle;
        private System.Windows.Forms.Button btnProd;
        private System.Windows.Forms.Button btnDash;
        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.Panel panelSubProd;
        private System.Windows.Forms.Button Brand;
        private System.Windows.Forms.Button Cat;
        private System.Windows.Forms.Button ProdL;
        private System.Windows.Forms.Panel panelSubRec;
        private System.Windows.Forms.Button POSAdj;
        private System.Windows.Forms.Button SaleHis;
        private System.Windows.Forms.Button Record;
        private System.Windows.Forms.Button Supplier;
        private System.Windows.Forms.Panel panelSubStock;
        private System.Windows.Forms.Button StockAdj;
        private System.Windows.Forms.Button StockEnt;
        private System.Windows.Forms.Button InStock;
        private System.Windows.Forms.Button Logout;
        private System.Windows.Forms.Panel SubSettings;
        private System.Windows.Forms.Button Store;
        private System.Windows.Forms.Button User;
        private System.Windows.Forms.Button Setting;
        private System.Windows.Forms.Label Role;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Username;
        private System.Windows.Forms.Label Title;
    }
}

