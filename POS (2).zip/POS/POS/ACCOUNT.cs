﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS
{
    public partial class ACCOUNT : Form
    {
        SqlConnection connection = new SqlConnection();
        SqlCommand command = new SqlCommand();
        DatabaseC dbcon = new DatabaseC();
        SqlDataReader dr;
        public ACCOUNT()
        {
            InitializeComponent();
            connection = new SqlConnection(dbcon.myConnection());
        }

        public void Clear()
        {
            textBoxFullName.Clear();
            textBoxPassword.Clear();
            textBoxConfirmPass.Clear();
            textBoxConfPass.Clear();
            textBoxUserName.Clear();
            comboBoxRole.Text = "";
            textBoxUserName.Focus();


        }

        private void metroTabPage1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Save_Click(object sender, EventArgs e)
        {
            try
            {
                if(textBoxPassword.Text != textBoxConfirmPass.Text)
                {
                    MessageBox.Show("Password did not match!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                connection.Open();
                command = new SqlCommand("INSERT  INTO tbUser(username, password, role, fullname) VALUES (@username, @password, @role, @fullname)", connection);
                command.Parameters.AddWithValue("@username", textBoxUserName.Text);
                command.Parameters.AddWithValue("@password", textBoxPassword.Text);
                command.Parameters.AddWithValue("@role", comboBoxRole.Text);
                command.Parameters.AddWithValue("@fullname", textBoxFullName.Text);
                command.ExecuteNonQuery();
                connection.Close();
                MessageBox.Show("New account has been successfully saved!", "Save Record", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Caution");
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            Clear();
        }
    }
}
