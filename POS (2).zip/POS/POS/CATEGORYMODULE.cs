﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS
{
    public partial class CATEGORYMODULE : Form
    {
        SqlConnection connection = new SqlConnection();
        SqlCommand command = new SqlCommand();
        DatabaseC dbcon = new DatabaseC();
        CATEGORY cat;

        public CATEGORYMODULE(CATEGORY c)
        {
            InitializeComponent();
            connection = new SqlConnection(dbcon.myConnection());
            cat = c;
        }

        public void Clear()
        {
            textBoxCategory.Clear();
            textBoxCategory.Focus();
            Save.Enabled = true;
            Update.Enabled = false;
        }

        private void Save_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Are you sure you want to save this category?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    connection.Open();
                    command = new SqlCommand("INSERT INTO tbCategory(category)VALUES(@category)", connection);
                    command.Parameters.AddWithValue("@category", textBoxCategory.Text);
                    command.ExecuteNonQuery();
                    connection.Close();
                    MessageBox.Show("Record has been successfully saved!", "Point Of Sales");
                    Clear();

                }
                cat.LoadCategory();
            }


            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void textBoxCategory_TextChanged(object sender, EventArgs e)
        {

        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void Update_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to update this category?", "Category Updated!", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                connection.Open();
            command = new SqlCommand("UPDATE tbCategory SET category = @category WHERE id LIKE'" + ID.Text + "'", connection);
            command.Parameters.AddWithValue("@category", textBoxCategory.Text);
            command.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("Category has been successfully updated!", "Point Of Sales");
            Clear();
            this.Dispose();
        }

        private void Close_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}
