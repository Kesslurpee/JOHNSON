﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS
{
    public partial class BRAND : Form
    {
        SqlConnection connection = new SqlConnection();
        SqlCommand command = new SqlCommand();
        DatabaseC dbcon = new DatabaseC();
        SqlDataReader dr;
        public BRAND()
        {
            InitializeComponent();
            connection = new SqlConnection(dbcon.myConnection());
            LoadBrand();
            
        }

        public void LoadBrand()
        {
            int i = 0;
            dataGridViewBrand.Rows.Clear();
            connection.Open();
            command = new SqlCommand("SELECT * FROM tbBrand ORDER BY brand", connection);
            dr = command.ExecuteReader();
            while (dr.Read()) 
            {
                i++;
                dataGridViewBrand.Rows.Add(i, dr["id"].ToString(), dr["brand"].ToString());
            }
            dr.Close();
            connection.Close();    
        }

        private void button1_Click(object sender, EventArgs e)
        {
            BRANDMODULE modFORM = new BRANDMODULE(this);
            modFORM.ShowDialog();
        }

        private void dataGridViewBrand_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string ColumnName = dataGridViewBrand.Columns[e.ColumnIndex].Name;
            if(ColumnName ==  "Delete")
            {

                if (MessageBox.Show("Are you sure you want to delete this record?", "Delete Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                    connection.Open();
                    command = new SqlCommand("DELETE FROM tbBrand WHERE id LIKE '" + dataGridViewBrand[1, e.RowIndex].Value.ToString() + "'", connection);
                    command.ExecuteNonQuery();
                    connection.Close();
                    MessageBox.Show("Brand has been successfully deleted!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else if (ColumnName =="Edit")
            {
                BRANDMODULE bm = new BRANDMODULE(this);
                bm.ID.Text = dataGridViewBrand[1, e.RowIndex].Value.ToString(); 
                bm.textBoxBrand.Text = dataGridViewBrand[2, e.RowIndex].Value.ToString();
                bm.Save.Enabled = false;
                bm.Update.Enabled = true;
                bm.ShowDialog();
            }
            LoadBrand();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
