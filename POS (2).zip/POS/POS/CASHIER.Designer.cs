﻿namespace POS
{
    partial class CASHIER
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CASHIER));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panelSlide = new System.Windows.Forms.Panel();
            this.buttonLogout = new System.Windows.Forms.Button();
            this.buttonChangeP = new System.Windows.Forms.Button();
            this.buttonDailySales = new System.Windows.Forms.Button();
            this.button5ClearCart = new System.Windows.Forms.Button();
            this.buttonSetPay = new System.Windows.Forms.Button();
            this.buttonAddDis = new System.Windows.Forms.Button();
            this.buttonSearchProd = new System.Windows.Forms.Button();
            this.buttonNewTransac = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.labelUserName = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.textBoxQuantity = new System.Windows.Forms.TextBox();
            this.labelTime = new System.Windows.Forms.Label();
            this.labelVATable = new System.Windows.Forms.Label();
            this.labelVAT = new System.Windows.Forms.Label();
            this.labelDIS = new System.Windows.Forms.Label();
            this.labelST = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxBar = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.labelDate = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.labelTransactionNo = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.labelDisTot = new System.Windows.Forms.Label();
            this.dataGridViewCashier = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colAdd = new System.Windows.Forms.DataGridViewImageColumn();
            this.colReduce = new System.Windows.Forms.DataGridViewImageColumn();
            this.Delete = new System.Windows.Forms.DataGridViewImageColumn();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCashier)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Maroon;
            this.panel1.Controls.Add(this.panelSlide);
            this.panel1.Controls.Add(this.buttonLogout);
            this.panel1.Controls.Add(this.buttonChangeP);
            this.panel1.Controls.Add(this.buttonDailySales);
            this.panel1.Controls.Add(this.button5ClearCart);
            this.panel1.Controls.Add(this.buttonSetPay);
            this.panel1.Controls.Add(this.buttonAddDis);
            this.panel1.Controls.Add(this.buttonSearchProd);
            this.panel1.Controls.Add(this.buttonNewTransac);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 661);
            this.panel1.TabIndex = 0;
            // 
            // panelSlide
            // 
            this.panelSlide.Location = new System.Drawing.Point(200, 178);
            this.panelSlide.Name = "panelSlide";
            this.panelSlide.Size = new System.Drawing.Size(21, 100);
            this.panelSlide.TabIndex = 4;
            // 
            // buttonLogout
            // 
            this.buttonLogout.BackColor = System.Drawing.Color.Maroon;
            this.buttonLogout.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.buttonLogout.FlatAppearance.BorderSize = 0;
            this.buttonLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonLogout.ForeColor = System.Drawing.Color.White;
            this.buttonLogout.Location = new System.Drawing.Point(0, 616);
            this.buttonLogout.Name = "buttonLogout";
            this.buttonLogout.Size = new System.Drawing.Size(200, 45);
            this.buttonLogout.TabIndex = 11;
            this.buttonLogout.Text = "Logout";
            this.buttonLogout.UseVisualStyleBackColor = false;
            this.buttonLogout.Click += new System.EventHandler(this.button8_Click);
            // 
            // buttonChangeP
            // 
            this.buttonChangeP.BackColor = System.Drawing.Color.Maroon;
            this.buttonChangeP.Dock = System.Windows.Forms.DockStyle.Top;
            this.buttonChangeP.FlatAppearance.BorderSize = 0;
            this.buttonChangeP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonChangeP.ForeColor = System.Drawing.Color.White;
            this.buttonChangeP.Image = ((System.Drawing.Image)(resources.GetObject("buttonChangeP.Image")));
            this.buttonChangeP.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.buttonChangeP.Location = new System.Drawing.Point(0, 410);
            this.buttonChangeP.Name = "buttonChangeP";
            this.buttonChangeP.Size = new System.Drawing.Size(200, 45);
            this.buttonChangeP.TabIndex = 10;
            this.buttonChangeP.Text = "Change Password";
            this.buttonChangeP.UseVisualStyleBackColor = false;
            this.buttonChangeP.Click += new System.EventHandler(this.button7_Click);
            // 
            // buttonDailySales
            // 
            this.buttonDailySales.BackColor = System.Drawing.Color.Maroon;
            this.buttonDailySales.Dock = System.Windows.Forms.DockStyle.Top;
            this.buttonDailySales.FlatAppearance.BorderSize = 0;
            this.buttonDailySales.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonDailySales.ForeColor = System.Drawing.Color.White;
            this.buttonDailySales.Image = ((System.Drawing.Image)(resources.GetObject("buttonDailySales.Image")));
            this.buttonDailySales.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.buttonDailySales.Location = new System.Drawing.Point(0, 364);
            this.buttonDailySales.Name = "buttonDailySales";
            this.buttonDailySales.Size = new System.Drawing.Size(200, 46);
            this.buttonDailySales.TabIndex = 9;
            this.buttonDailySales.Text = "Daily Sales";
            this.buttonDailySales.UseVisualStyleBackColor = false;
            this.buttonDailySales.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5ClearCart
            // 
            this.button5ClearCart.BackColor = System.Drawing.Color.Maroon;
            this.button5ClearCart.Dock = System.Windows.Forms.DockStyle.Top;
            this.button5ClearCart.FlatAppearance.BorderSize = 0;
            this.button5ClearCart.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button5ClearCart.ForeColor = System.Drawing.Color.White;
            this.button5ClearCart.Image = ((System.Drawing.Image)(resources.GetObject("button5ClearCart.Image")));
            this.button5ClearCart.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.button5ClearCart.Location = new System.Drawing.Point(0, 324);
            this.button5ClearCart.Name = "button5ClearCart";
            this.button5ClearCart.Size = new System.Drawing.Size(200, 40);
            this.button5ClearCart.TabIndex = 8;
            this.button5ClearCart.Text = "Clear Cart";
            this.button5ClearCart.UseVisualStyleBackColor = false;
            this.button5ClearCart.Click += new System.EventHandler(this.button5_Click);
            // 
            // buttonSetPay
            // 
            this.buttonSetPay.BackColor = System.Drawing.Color.Maroon;
            this.buttonSetPay.Dock = System.Windows.Forms.DockStyle.Top;
            this.buttonSetPay.FlatAppearance.BorderSize = 0;
            this.buttonSetPay.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonSetPay.ForeColor = System.Drawing.Color.White;
            this.buttonSetPay.Image = ((System.Drawing.Image)(resources.GetObject("buttonSetPay.Image")));
            this.buttonSetPay.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.buttonSetPay.Location = new System.Drawing.Point(0, 284);
            this.buttonSetPay.Name = "buttonSetPay";
            this.buttonSetPay.Size = new System.Drawing.Size(200, 40);
            this.buttonSetPay.TabIndex = 7;
            this.buttonSetPay.Text = "Settle Payment";
            this.buttonSetPay.UseVisualStyleBackColor = false;
            this.buttonSetPay.Click += new System.EventHandler(this.button4_Click);
            // 
            // buttonAddDis
            // 
            this.buttonAddDis.BackColor = System.Drawing.Color.Maroon;
            this.buttonAddDis.Dock = System.Windows.Forms.DockStyle.Top;
            this.buttonAddDis.FlatAppearance.BorderSize = 0;
            this.buttonAddDis.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonAddDis.ForeColor = System.Drawing.Color.White;
            this.buttonAddDis.Image = ((System.Drawing.Image)(resources.GetObject("buttonAddDis.Image")));
            this.buttonAddDis.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.buttonAddDis.Location = new System.Drawing.Point(0, 244);
            this.buttonAddDis.Name = "buttonAddDis";
            this.buttonAddDis.Size = new System.Drawing.Size(200, 40);
            this.buttonAddDis.TabIndex = 6;
            this.buttonAddDis.Text = "Add Discount";
            this.buttonAddDis.UseVisualStyleBackColor = false;
            this.buttonAddDis.Click += new System.EventHandler(this.button3_Click);
            // 
            // buttonSearchProd
            // 
            this.buttonSearchProd.BackColor = System.Drawing.Color.Maroon;
            this.buttonSearchProd.Dock = System.Windows.Forms.DockStyle.Top;
            this.buttonSearchProd.FlatAppearance.BorderSize = 0;
            this.buttonSearchProd.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonSearchProd.ForeColor = System.Drawing.Color.White;
            this.buttonSearchProd.Image = ((System.Drawing.Image)(resources.GetObject("buttonSearchProd.Image")));
            this.buttonSearchProd.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.buttonSearchProd.Location = new System.Drawing.Point(0, 204);
            this.buttonSearchProd.Name = "buttonSearchProd";
            this.buttonSearchProd.Size = new System.Drawing.Size(200, 40);
            this.buttonSearchProd.TabIndex = 5;
            this.buttonSearchProd.Text = "Search Product";
            this.buttonSearchProd.UseVisualStyleBackColor = false;
            this.buttonSearchProd.Click += new System.EventHandler(this.button2_Click);
            // 
            // buttonNewTransac
            // 
            this.buttonNewTransac.BackColor = System.Drawing.Color.Maroon;
            this.buttonNewTransac.Dock = System.Windows.Forms.DockStyle.Top;
            this.buttonNewTransac.FlatAppearance.BorderSize = 0;
            this.buttonNewTransac.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonNewTransac.ForeColor = System.Drawing.Color.White;
            this.buttonNewTransac.Image = ((System.Drawing.Image)(resources.GetObject("buttonNewTransac.Image")));
            this.buttonNewTransac.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.buttonNewTransac.Location = new System.Drawing.Point(0, 158);
            this.buttonNewTransac.Name = "buttonNewTransac";
            this.buttonNewTransac.Size = new System.Drawing.Size(200, 46);
            this.buttonNewTransac.TabIndex = 4;
            this.buttonNewTransac.Text = "New Transaction";
            this.buttonNewTransac.UseVisualStyleBackColor = false;
            this.buttonNewTransac.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Maroon;
            this.panel2.Controls.Add(this.labelUserName);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 158);
            this.panel2.TabIndex = 1;
            // 
            // labelUserName
            // 
            this.labelUserName.AutoSize = true;
            this.labelUserName.ForeColor = System.Drawing.Color.White;
            this.labelUserName.Location = new System.Drawing.Point(66, 112);
            this.labelUserName.Name = "labelUserName";
            this.labelUserName.Size = new System.Drawing.Size(83, 18);
            this.labelUserName.TabIndex = 4;
            this.labelUserName.Text = "UserName";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(56, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(93, 88);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Maroon;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(200, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(27, 661);
            this.panel3.TabIndex = 1;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Maroon;
            this.panel4.Controls.Add(this.button1);
            this.panel4.Controls.Add(this.pictureBox2);
            this.panel4.Controls.Add(this.label1);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(227, 612);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(957, 49);
            this.panel4.TabIndex = 2;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(870, 10);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 27);
            this.button1.TabIndex = 5;
            this.button1.Text = "Close";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(6, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(54, 43);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(66, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 18);
            this.label1.TabIndex = 4;
            this.label1.Text = "Name and Role";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.textBoxQuantity);
            this.panel5.Controls.Add(this.labelTime);
            this.panel5.Controls.Add(this.labelVATable);
            this.panel5.Controls.Add(this.labelVAT);
            this.panel5.Controls.Add(this.labelDIS);
            this.panel5.Controls.Add(this.labelST);
            this.panel5.Controls.Add(this.label11);
            this.panel5.Controls.Add(this.label10);
            this.panel5.Controls.Add(this.label9);
            this.panel5.Controls.Add(this.label8);
            this.panel5.Controls.Add(this.textBoxBar);
            this.panel5.Controls.Add(this.label7);
            this.panel5.Controls.Add(this.labelDate);
            this.panel5.Controls.Add(this.label6);
            this.panel5.Controls.Add(this.labelTransactionNo);
            this.panel5.Controls.Add(this.label3);
            this.panel5.Controls.Add(this.labelDisTot);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel5.Location = new System.Drawing.Point(984, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(200, 612);
            this.panel5.TabIndex = 3;
            // 
            // textBoxQuantity
            // 
            this.textBoxQuantity.Location = new System.Drawing.Point(162, 261);
            this.textBoxQuantity.Name = "textBoxQuantity";
            this.textBoxQuantity.Size = new System.Drawing.Size(35, 26);
            this.textBoxQuantity.TabIndex = 16;
            this.textBoxQuantity.Text = "1";
            this.textBoxQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // labelTime
            // 
            this.labelTime.BackColor = System.Drawing.Color.Firebrick;
            this.labelTime.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.labelTime.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTime.ForeColor = System.Drawing.Color.White;
            this.labelTime.Location = new System.Drawing.Point(0, 578);
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(200, 34);
            this.labelTime.TabIndex = 15;
            this.labelTime.Text = "00:00:00";
            this.labelTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelVATable
            // 
            this.labelVATable.Location = new System.Drawing.Point(100, 445);
            this.labelVATable.Name = "labelVATable";
            this.labelVATable.Size = new System.Drawing.Size(97, 18);
            this.labelVATable.TabIndex = 14;
            this.labelVATable.Text = "0.00";
            this.labelVATable.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelVAT
            // 
            this.labelVAT.Location = new System.Drawing.Point(100, 411);
            this.labelVAT.Name = "labelVAT";
            this.labelVAT.Size = new System.Drawing.Size(97, 18);
            this.labelVAT.TabIndex = 13;
            this.labelVAT.Text = "0.00";
            this.labelVAT.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelDIS
            // 
            this.labelDIS.Location = new System.Drawing.Point(103, 377);
            this.labelDIS.Name = "labelDIS";
            this.labelDIS.Size = new System.Drawing.Size(97, 18);
            this.labelDIS.TabIndex = 12;
            this.labelDIS.Text = "0.00";
            this.labelDIS.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelST
            // 
            this.labelST.Location = new System.Drawing.Point(100, 343);
            this.labelST.Name = "labelST";
            this.labelST.Size = new System.Drawing.Size(97, 18);
            this.labelST.TabIndex = 11;
            this.labelST.Text = "0.00";
            this.labelST.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 445);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(69, 18);
            this.label11.TabIndex = 10;
            this.label11.Text = " VATable";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 411);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(39, 18);
            this.label10.TabIndex = 9;
            this.label10.Text = "VAT:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 377);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(73, 18);
            this.label9.TabIndex = 8;
            this.label9.Text = "Discount:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 343);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(88, 18);
            this.label8.TabIndex = 7;
            this.label8.Text = "Sales Total:";
            // 
            // textBoxBar
            // 
            this.textBoxBar.Location = new System.Drawing.Point(9, 261);
            this.textBoxBar.Name = "textBoxBar";
            this.textBoxBar.Size = new System.Drawing.Size(147, 26);
            this.textBoxBar.TabIndex = 6;
            this.textBoxBar.TextChanged += new System.EventHandler(this.textBoxBar_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(6, 235);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(68, 18);
            this.label7.TabIndex = 5;
            this.label7.Text = "Barcode";
            // 
            // labelDate
            // 
            this.labelDate.AutoSize = true;
            this.labelDate.Location = new System.Drawing.Point(6, 199);
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(71, 18);
            this.labelDate.TabIndex = 4;
            this.labelDate.Text = "0000000";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(6, 163);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 18);
            this.label6.TabIndex = 3;
            this.label6.Text = "Date";
            // 
            // labelTransactionNo
            // 
            this.labelTransactionNo.AutoSize = true;
            this.labelTransactionNo.Location = new System.Drawing.Point(6, 127);
            this.labelTransactionNo.Name = "labelTransactionNo";
            this.labelTransactionNo.Size = new System.Drawing.Size(89, 18);
            this.labelTransactionNo.TabIndex = 2;
            this.labelTransactionNo.Text = "000000000";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 91);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 18);
            this.label3.TabIndex = 1;
            this.label3.Text = "Transaction No";
            // 
            // labelDisTot
            // 
            this.labelDisTot.BackColor = System.Drawing.Color.Maroon;
            this.labelDisTot.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelDisTot.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDisTot.ForeColor = System.Drawing.Color.White;
            this.labelDisTot.Location = new System.Drawing.Point(0, 0);
            this.labelDisTot.Name = "labelDisTot";
            this.labelDisTot.Size = new System.Drawing.Size(200, 31);
            this.labelDisTot.TabIndex = 0;
            this.labelDisTot.Text = "0.00";
            this.labelDisTot.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // dataGridViewCashier
            // 
            this.dataGridViewCashier.AllowUserToAddRows = false;
            this.dataGridViewCashier.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewCashier.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.DimGray;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCashier.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewCashier.ColumnHeadersHeight = 30;
            this.dataGridViewCashier.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridViewCashier.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column9,
            this.Column2,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column8,
            this.colAdd,
            this.colReduce,
            this.Delete});
            this.dataGridViewCashier.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewCashier.EnableHeadersVisualStyles = false;
            this.dataGridViewCashier.Location = new System.Drawing.Point(227, 0);
            this.dataGridViewCashier.Name = "dataGridViewCashier";
            this.dataGridViewCashier.RowHeadersVisible = false;
            this.dataGridViewCashier.Size = new System.Drawing.Size(757, 612);
            this.dataGridViewCashier.TabIndex = 4;
            this.dataGridViewCashier.SelectionChanged += new System.EventHandler(this.dataGridViewCashier_SelectionChanged);
            // 
            // Column1
            // 
            this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column1.HeaderText = "No";
            this.Column1.Name = "Column1";
            this.Column1.Width = 51;
            // 
            // Column9
            // 
            this.Column9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column9.HeaderText = "Id";
            this.Column9.Name = "Column9";
            this.Column9.Width = 43;
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column2.HeaderText = "ProdCode";
            this.Column2.Name = "Column2";
            this.Column2.Width = 104;
            // 
            // Column4
            // 
            this.Column4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column4.HeaderText = "Description";
            this.Column4.Name = "Column4";
            // 
            // Column5
            // 
            this.Column5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column5.DefaultCellStyle = dataGridViewCellStyle2;
            this.Column5.HeaderText = "Price";
            this.Column5.Name = "Column5";
            this.Column5.Width = 68;
            // 
            // Column6
            // 
            this.Column6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.Column6.DefaultCellStyle = dataGridViewCellStyle3;
            this.Column6.HeaderText = "Qty";
            this.Column6.Name = "Column6";
            this.Column6.Width = 54;
            // 
            // Column7
            // 
            this.Column7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.Column7.DefaultCellStyle = dataGridViewCellStyle4;
            this.Column7.HeaderText = "Discount";
            this.Column7.Name = "Column7";
            this.Column7.Width = 92;
            // 
            // Column8
            // 
            this.Column8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.Column8.DefaultCellStyle = dataGridViewCellStyle5;
            this.Column8.HeaderText = "Total";
            this.Column8.Name = "Column8";
            this.Column8.Width = 63;
            // 
            // colAdd
            // 
            this.colAdd.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.colAdd.HeaderText = "";
            this.colAdd.Image = ((System.Drawing.Image)(resources.GetObject("colAdd.Image")));
            this.colAdd.Name = "colAdd";
            this.colAdd.Width = 5;
            // 
            // colReduce
            // 
            this.colReduce.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.colReduce.HeaderText = "";
            this.colReduce.Image = ((System.Drawing.Image)(resources.GetObject("colReduce.Image")));
            this.colReduce.Name = "colReduce";
            this.colReduce.Width = 5;
            // 
            // Delete
            // 
            this.Delete.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Delete.HeaderText = "";
            this.Delete.Image = ((System.Drawing.Image)(resources.GetObject("Delete.Image")));
            this.Delete.Name = "Delete";
            this.Delete.Width = 5;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // CASHIER
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1184, 661);
            this.Controls.Add(this.dataGridViewCashier);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "CASHIER";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CASHIER";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCashier)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button buttonNewTransac;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button buttonLogout;
        private System.Windows.Forms.Button buttonChangeP;
        private System.Windows.Forms.Button buttonDailySales;
        private System.Windows.Forms.Button button5ClearCart;
        private System.Windows.Forms.Button buttonSetPay;
        private System.Windows.Forms.Button buttonAddDis;
        private System.Windows.Forms.Button buttonSearchProd;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panelSlide;
        private System.Windows.Forms.DataGridView dataGridViewCashier;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelDisTot;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label labelDate;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label labelVATable;
        private System.Windows.Forms.Label labelVAT;
        private System.Windows.Forms.Label labelDIS;
        private System.Windows.Forms.Label labelST;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label labelTime;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button button1;
        public System.Windows.Forms.Label labelUserName;
        public System.Windows.Forms.Label labelTransactionNo;
        private System.Windows.Forms.TextBox textBoxQuantity;
        public System.Windows.Forms.TextBox textBoxBar;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewImageColumn colAdd;
        private System.Windows.Forms.DataGridViewImageColumn colReduce;
        private System.Windows.Forms.DataGridViewImageColumn Delete;
    }
}