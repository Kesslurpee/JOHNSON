﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS
{
    public partial class SUPPLYMODULE : Form
    {
        SqlConnection connection = new SqlConnection();
        SqlCommand command = new SqlCommand();
        DatabaseC dbcon = new DatabaseC();
        string title = "Point of Sales";
        SUPPLIER supplier;
        public SUPPLYMODULE(SUPPLIER supply)
        {
            InitializeComponent();
            connection = new SqlConnection(dbcon.myConnection());
            supplier = supply;
        }

        private void Close_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        public void Clear()
        {
            textBoxAddress.Clear();
            textBoxContactPerson.Clear();
            textBoxEmail.Clear();
            textBoxFax.Clear();
            textBoxPhoneNumber.Clear();
            textBoxSupplierName.Clear();

            Save.Enabled = true;
            Update.Enabled = false;
            textBoxSupplierName.Focus();
        }

        private void Save_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Are you sure you want to save this record?", "CONFIRM", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    connection.Open();
                    command = new SqlCommand("INSERT INTO tbSupplier(supplier, address, contactperson, phone, email, fax) VALUES(@supplier, @address, @contactperson, @phone, @email, @fax)", connection);
                    command.Parameters.AddWithValue("@supplier", textBoxSupplierName.Text);
                    command.Parameters.AddWithValue("@address", textBoxAddress.Text);
                    command.Parameters.AddWithValue("@contactperson", textBoxContactPerson.Text);
                    command.Parameters.AddWithValue("@phone", textBoxPhoneNumber.Text);
                    command.Parameters.AddWithValue("@email", textBoxEmail.Text);   
                    command.Parameters.AddWithValue("@fax", textBoxFax.Text);
                    command.ExecuteNonQuery();
                    connection.Close();
                    MessageBox.Show("Record has been successfully saved!", "Save Record", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Clear();
                    supplier.LoadSupplier();
                }
            }
            catch (Exception)
            {

            }
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void Update_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Are you sure you want to update this record? Click yes to confirm.", "CONFIRM", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    connection.Open();
                    command = new SqlCommand("UPDATE tbSupplier SET supplier = @supplier, address = @address, contactperson = @contactperson, phone = @phone, email = @email, fax = @fax WHERE id = @id", connection);
                    command.Parameters.AddWithValue("@id", ID.Text);
                    command.Parameters.AddWithValue("@supplier", textBoxSupplierName.Text);
                    command.Parameters.AddWithValue("@address", textBoxAddress.Text);
                    command.Parameters.AddWithValue("@contactperson", textBoxContactPerson.Text);
                    command.Parameters.AddWithValue("@phone", textBoxPhoneNumber.Text);
                    command.Parameters.AddWithValue("@email", textBoxEmail.Text);
                    command.Parameters.AddWithValue("@fax", textBoxFax.Text);
                    command.ExecuteNonQuery();
                    connection.Close();
                    MessageBox.Show("Record has been successfully updated!", "Update Record", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Dispose();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Warning");
            }
        }
    }
}
