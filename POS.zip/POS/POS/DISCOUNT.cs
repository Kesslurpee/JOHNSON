﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS
{
    public partial class DISCOUNT : Form
    {
        SqlConnection connection = new SqlConnection();
        SqlCommand command = new SqlCommand();
        DatabaseC dbcon = new DatabaseC();
        
        CASHIER cashier;
        
        string title = "Point of Sales";
        public DISCOUNT(CASHIER cash)
        {
            InitializeComponent();
            connection = new SqlConnection(dbcon.myConnection());
            cashier = cash;
            textBoxDiscountPercentage.Focus();
            this.KeyPreview = true;
        }

        private void Close_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void DISCOUNT_KeyDown(object sender, KeyEventArgs e)
        {
            
            if (e.KeyCode == Keys.Enter) this.Dispose();
            else if (e.KeyCode == Keys.Enter) buttonConfirm.PerformClick();
        }

        private void textBoxDiscountPercentage_TextChanged(object sender, EventArgs e)
        {
            try
            {
                double discount = double.Parse(textBoxPrice.Text) * double.Parse(textBoxDiscountPercentage.Text) * 0.01;
                textBoxDiscAmount.Text = discount.ToString("#,##0.00");
            }
            catch (Exception) 
            {
                textBoxDiscAmount.Text = "0.00";
            }
        }

        private void buttonConfirm_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Add discount? Click yes to confirm.", title, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    connection.Open();
                    command = new SqlCommand("UPDATE tbCart SET discount_percentage = @discount_percentage WHERE id = @id", connection);
                    command.Parameters.AddWithValue("@discount_percentage", double.Parse(textBoxDiscountPercentage.Text));
                    command.Parameters.AddWithValue("@id", int.Parse(labelId.Text));
                    command.ExecuteNonQuery();
                    connection.Close();
                    cashier.LoadCart();
                    this.Dispose();
                }
            }
            catch (Exception ex)
            {
                connection.Close();
                MessageBox.Show(ex.Message, title);
            }
        }

        private void DISCOUNT_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBoxDiscAmount_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
