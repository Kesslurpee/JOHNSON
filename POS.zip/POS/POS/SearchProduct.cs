﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS
{
    public partial class SearchProduct : Form
    {
        SqlConnection connection = new SqlConnection();
        SqlCommand command = new SqlCommand();
        DatabaseC dbcon = new DatabaseC();
        SqlDataReader dr;
        CASHIER cashier;

        
        public SearchProduct(CASHIER cash)
        {
            InitializeComponent();
            connection = new SqlConnection(dbcon.myConnection());
            cashier = cash;
            LoadProduct();

        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        public void LoadProduct()
        {
            int i = 0;
            dataGridViewProduct.Rows.Clear();
            command = new SqlCommand("SELECT p.prodcode, p.barcode, p.proddesc, b.brand, c.category, p.price, p.qty FROM tbProduct AS p INNER JOIN tbBrand AS b ON b.id = p.bid INNER JOIN tbCategory AS c on c.id = p.cid WHERE CONCAT(p.proddesc, b.brand, c.category) LIKE '%" + metroTextBoxSearch.Text + "%'", connection);
            connection.Open();
            dr = command.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataGridViewProduct.Rows.Add(i, dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(), dr[4].ToString(), dr[5].ToString(), dr[6].ToString());
            }
            dr.Close();
            connection.Close();
           
        }

        private void dataGridViewProduct_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string ColumnName = dataGridViewProduct.Columns[e.ColumnIndex].Name;
            if (ColumnName == "Select")
            {
                Quantity quantity = new Quantity(cashier);
                quantity.ProductDetails(dataGridViewProduct.Rows[e.RowIndex].Cells[1].Value.ToString(), double.Parse(dataGridViewProduct.Rows[e.RowIndex].Cells[6].Value.ToString()), cashier.labelTransactionNo.Text, int.Parse(dataGridViewProduct.Rows[e.RowIndex].Cells[7].Value.ToString()));
                quantity.ShowDialog();
            }
        }

        private void metroTextBoxSearch_TextChanged(object sender, EventArgs e)
        {
            LoadProduct();
        }

        private void dataGridViewProduct_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                this.Dispose();
            }
        }
    }
}
