﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS
{
    public partial class CATEGORY : Form
    {
        SqlConnection connection = new SqlConnection();
        SqlCommand command = new SqlCommand();
        DatabaseC dbcon = new DatabaseC();
        SqlDataReader dr;
        public CATEGORY()
        {
            InitializeComponent();
            connection = new SqlConnection(dbcon.myConnection());
            LoadCategory();
        }

        public void LoadCategory()
        {
            int i = 0;
            dataGridViewCategory.Rows.Clear();
            connection.Open();
            command = new SqlCommand("SELECT * FROM tbCategory ORDER BY category", connection);
            dr = command.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataGridViewCategory.Rows.Add(i, dr["id"].ToString(), dr["category"].ToString());
            }
            dr.Close();
            connection.Close();
        }

        private void Add_Click(object sender, EventArgs e)
        {
            CATEGORYMODULE catFORM = new CATEGORYMODULE(this);
            catFORM.ShowDialog();
        }

        private void dataGridViewCategory_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string ColumnName = dataGridViewCategory.Columns[e.ColumnIndex].Name;
            if (ColumnName == "Delete")
            {

                if (MessageBox.Show("Are you sure you want to delete this category?", "Delete Category", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    connection.Open();
                    command = new SqlCommand("DELETE FROM tbCategory WHERE id LIKE '" + dataGridViewCategory[1, e.RowIndex].Value.ToString() + "'", connection);
                    command.ExecuteNonQuery();
                    connection.Close();
                    MessageBox.Show("Category has been successfully deleted!", "Point Of Sales", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else if (ColumnName == "Edit")
            {
                CATEGORYMODULE cat = new CATEGORYMODULE(this);
                cat.ID.Text = dataGridViewCategory[1, e.RowIndex].Value.ToString();
                cat.textBoxCategory.Text = dataGridViewCategory[2, e.RowIndex].Value.ToString();
                cat.Save.Enabled = false;
                cat.Update.Enabled = true;
                cat.ShowDialog();
            }
            LoadCategory();
        }
    }
}
