﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS
{
    public partial class Quantity : Form
    {
        SqlConnection connection = new SqlConnection();
        SqlCommand command = new SqlCommand();
        DatabaseC dbcon = new DatabaseC();
        SqlDataReader dr;
        CASHIER cashier;
        string title = "Point of Sales";

        private string prodcode;
        private double price;
        private String transactionno;
        private int quantity;
        public Quantity(CASHIER cash)
        {
            InitializeComponent();
            connection = new SqlConnection(dbcon.myConnection());
            cashier = cash;

        }

        public void ProductDetails(string prodcode, double price, string transactionno, int quantity)
        {
            this.prodcode = prodcode;
            this.price = price;
            this.transactionno = transactionno;
            this.quantity = quantity;
        }

        private void textBoxQuantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar == 13) && (textBoxQuantity.Text != string.Empty))
            {
                try
                {
                    string id = "";
                    int CartQuantity = 0;
                    bool discovered = false;
                    connection.Open();
                    command = new SqlCommand("SELECT * FROM tbCart WHERE transactionno = @transactionno and prodcode = @prodcode", connection);
                    command.Parameters.AddWithValue("@transactionno", prodcode);
                    command.Parameters.AddWithValue("@prodcode", prodcode);
                    dr = command.ExecuteReader();
                    dr.Read();

                    if (dr.HasRows)
                    {
                        id = dr["id"].ToString();
                        CartQuantity = int.Parse(dr["qty"].ToString());
                        discovered = true;
                    }
                    else discovered = false;
                    dr.Close();
                    connection.Close();

                    if (discovered)
                    {
                        if (quantity < (int.Parse(textBoxQuantity.Text) + CartQuantity))
                        {
                            MessageBox.Show("Incapable of proceeding. Remaining quantity on hand is" + quantity, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                        connection.Open();
                        command = new SqlCommand("UPDATE tbCart SET qty = (qty + " + int.Parse(textBoxQuantity.Text) + ")WHERE id = '" + id + "'", connection);
                        command.ExecuteNonQuery();
                        connection.Close();

                        cashier.LoadCart();
                        this.Dispose();
                    }
                    else
                    {
                        if (quantity < (int.Parse(textBoxQuantity.Text) + CartQuantity))
                        {
                            MessageBox.Show("Incapable of proceeding. Remaining quantity on hand is" + quantity, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }

                        connection.Open();
                        command = new SqlCommand("INSERT INTO tbCart(transactionno, prodcode, price, qty, date, cashier) VALUES(@transactionno, @prodcode, @price, @qty, @date, @cashier)", connection);
                        command.Parameters.AddWithValue("@transactionno", transactionno);
                        command.Parameters.AddWithValue("@prodcode", prodcode);
                        command.Parameters.AddWithValue("@price", price);
                        command.Parameters.AddWithValue("@qty", int.Parse(textBoxQuantity.Text));
                        command.Parameters.AddWithValue("@date", DateTime.Now);
                        command.Parameters.AddWithValue("@cashier", cashier.labelUserName.Text);
                        command.ExecuteNonQuery();
                        connection.Close();
                        cashier.textBoxBar.Clear();
                        cashier.textBoxBar.Focus();
                        cashier.LoadCart();
                        this.Dispose();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, title);
                }
            }


        }

    }
}
    



