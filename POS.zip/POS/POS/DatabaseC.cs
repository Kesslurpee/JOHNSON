﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS
{
    class DatabaseC
    {
        SqlConnection con = new SqlConnection();
        SqlCommand command = new SqlCommand();
        private string connection;
        public string myConnection()
        {
            connection = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=C__USERS_RONKE_DOCUMENTS_POSALE;Integrated Security=True;Connect Timeout=30";
            return connection;
        }

        public DataTable getTable(string tb)
        {
            con.ConnectionString = myConnection();
            command= new SqlCommand(tb, con);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            return table;
        }

        public void ExecuteNonQuery(String sql)
        {
            try
            {
                con.ConnectionString = myConnection();
                con.Open();
                command = new SqlCommand(sql, con);
                command.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }
    }
}
