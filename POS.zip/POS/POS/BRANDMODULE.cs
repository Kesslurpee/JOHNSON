﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS
{
    public partial class BRANDMODULE : Form
    {
        SqlConnection connection = new SqlConnection();
        SqlCommand command = new SqlCommand();
        DatabaseC dbcon = new DatabaseC();
        BRAND br;

        
        public BRANDMODULE(BRAND brand)
        {
            InitializeComponent();
            connection = new SqlConnection(dbcon.myConnection());
            br = brand;
            
        }

        private void Close_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void Save_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Are you sure you want to save this brand?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    connection.Open();
                    command = new SqlCommand("INSERT INTO tbBrand(brand)VALUES(@brand)", connection);
                    command.Parameters.AddWithValue("@brand", textBoxBrand.Text);
                    command.ExecuteNonQuery();
                    connection.Close();
                    MessageBox.Show("Record has been successfully saved!", "POS");
                    Clear();
                    br.LoadBrand();
                }
            }


            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            Clear();
        }

        public void Clear()
        {
            textBoxBrand.Clear();
            Update.Enabled = false;
            Save.Enabled = true;
            textBoxBrand.Focus();
        }

        private void Update_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to update this brand?", "Record Updated!", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                connection.Open();
            command = new SqlCommand("UPDATE tbBrand SET brand = @brand WHERE id LIKE'" + ID.Text + "'", connection);
            command.Parameters.AddWithValue("@brand", textBoxBrand.Text);
            command.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("Brand has been successfully updated!", "POS");
            Clear();
            this.Dispose();

        }

        private void BRANDMODULE_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}

