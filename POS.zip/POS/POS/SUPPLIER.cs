﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS
{
    public partial class SUPPLIER : Form
    {
        SqlConnection connection = new SqlConnection();
        SqlCommand command = new SqlCommand();
        DatabaseC dbcon = new DatabaseC();
        SqlDataReader dr;
        public SUPPLIER()
        {
            InitializeComponent();
            connection = new SqlConnection(dbcon.myConnection());
            LoadSupplier();
        }

        public void LoadSupplier()
        {
            dataGridViewSupplier.Rows.Clear();
            int i = 0;
            connection.Open();
            command = new SqlCommand("SELECT * FROM tbSupplier", connection);
            dr = command.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataGridViewSupplier.Rows.Add(i, dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(), dr[4].ToString(), dr[5].ToString(), dr[6].ToString());
            }
            dr.Close();
            connection.Close();
        }

        private void Add_Click(object sender, EventArgs e)
        {
            SUPPLYMODULE supplymodule = new SUPPLYMODULE(this);
            supplymodule.ShowDialog();
        }

        private void dataGridViewSupplier_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string ColumnName = dataGridViewSupplier.Columns[e.ColumnIndex].Name;
            if (ColumnName == "Edit")
            {
                SUPPLYMODULE supplymodule = new SUPPLYMODULE(this);
                supplymodule.ID.Text = dataGridViewSupplier.Rows[e.RowIndex].Cells[1].Value.ToString();
                supplymodule.textBoxSupplierName.Text = dataGridViewSupplier.Rows[e.RowIndex].Cells[2].Value.ToString();
                supplymodule.textBoxAddress.Text = dataGridViewSupplier.Rows[e.RowIndex].Cells[3].Value.ToString();   
                supplymodule.textBoxContactPerson.Text = dataGridViewSupplier.Rows[e.RowIndex].Cells[4].Value.ToString();
                supplymodule.textBoxPhoneNumber.Text = dataGridViewSupplier.Rows[e.RowIndex].Cells[5].Value.ToString();
                supplymodule.textBoxEmail.Text = dataGridViewSupplier.Rows[e.RowIndex].Cells[6].Value.ToString();
                supplymodule.textBoxFax.Text = dataGridViewSupplier.Rows[e.RowIndex].Cells[7].Value.ToString();

                supplymodule.Save.Enabled = false;
                supplymodule.Update.Enabled = true;
                supplymodule.ShowDialog();



            }
            else if(ColumnName == "Delete")
            {
                if (MessageBox.Show("Are you sure you want to delete this record? Click yes to confirm", "CONFIRM", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    connection.Open();
                    command = new SqlCommand("DELETE  FROM tbSupplier WHERE id LIKE '" + dataGridViewSupplier.Rows[e.RowIndex].Cells[1].Value.ToString() + "'", connection);
                    command.ExecuteNonQuery();
                    connection.Close();
                    MessageBox.Show("Record has been successfully deleted!", "Delete Record", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    
                }
            }
            LoadSupplier();
        }
    }
}
