﻿using System;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace POS
{
    public partial class CASHIER : Form
    {
        SqlConnection connection = new SqlConnection();
        SqlCommand command = new SqlCommand();
        DatabaseC dbcon = new DatabaseC();
        SqlDataReader dr;

        int quantity;
        string id;
        string price;


        string title = "Point of Sales";
        public CASHIER()
        {
            InitializeComponent();
            connection = new SqlConnection(dbcon.myConnection());
            GetTransactionNo();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Close_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        public void slide(Button button)
        {
            panelSlide.BackColor = Color.White;
            panelSlide.Height = button.Height;
            panelSlide.Top = button.Top;
        }
        #region button

        private void button1_Click(object sender, EventArgs e)
        {
            slide(buttonNewTransac);
            GetTransactionNo();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            slide(buttonSearchProd);
            SearchProduct SearchProd = new SearchProduct(this);
            SearchProd.LoadProduct();
            SearchProd.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            slide(buttonAddDis);
            DISCOUNT dISCOUNT = new DISCOUNT(this);
            dISCOUNT.labelId.Text = id;
            dISCOUNT.textBoxPrice.Text = price;
            dISCOUNT.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            slide(buttonSetPay);
            PAYMENT pay = new PAYMENT(this);
            pay.textBoxSale.Text = labelDisTot.Text;
            pay.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            slide(button5ClearCart);

            if (MessageBox.Show("Are you sure you want to remove all items from cart?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                connection.Open();
                command = new SqlCommand("DELETE  FROM tbCart WHERE transactionno LIKE '" + labelTransactionNo.Text + "'", connection);
                command.ExecuteNonQuery();
                connection.Close();
                MessageBox.Show("All items have been successfully removed!", "Remove item", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadCart();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            slide(buttonDailySales);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            slide(buttonChangeP);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            slide(buttonLogout);
            if (MessageBox.Show("Are you sure you want to Logout?", "Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Hide();
                LoginForm login = new LoginForm();
                login.ShowDialog();
            }

        }
        #endregion button

        public void LoadCart()
        {
            try
            {
                Boolean cart = false;
                int i = 0;
                double total = 0;
                double discount = 0;
                dataGridViewCashier.Rows.Clear();
                connection.Open();
                command = new SqlCommand("SELECT c.id, c.prodcode, p.proddesc, c.qty, c.price, c.discount, c.total FROM tbCart AS c INNER JOIN tbProduct AS p ON c.prodcode=p.prodcode WHERE c.transactionno LIKE @transactionno AND c.stat LIKE 'Pending'", connection);
                command.Parameters.AddWithValue("@transactionno", labelTransactionNo.Text);
                dr = command.ExecuteReader();
                while (dr.Read())
                {

                    i++;
                    total += Convert.ToDouble(dr["total"].ToString());
                    discount += Convert.ToDouble(dr["discount"].ToString());
                    dataGridViewCashier.Rows.Add(i, dr["id"].ToString(), dr["prodcode"].ToString(), dr["proddesc"].ToString(), dr["price"].ToString(), dr["qty"].ToString(), dr["discount"].ToString(), double.Parse(dr["total"].ToString()).ToString("#,##0.00"));
                    cart = true;

                }
                dr.Close();
                connection.Close();
                labelST.Text = total.ToString("#,##0.00");
                labelDisTot.Text = discount.ToString("#,##0.00");
                GetCartTotal();
                if (cart)
                {
                    button5ClearCart.Enabled = true;
                    buttonSetPay.Enabled = true;
                    buttonAddDis.Enabled = true;
                }
                else
                {
                    button5ClearCart.Enabled = false;
                    buttonSetPay.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, title);
            }


        }

        public void GetCartTotal()
        {
            double discount = double.Parse(labelDIS.Text);
            double sales = double.Parse(labelST.Text) - discount;
            double VAT = sales * 0.12;
            double VATable = sales - VAT;

            labelVAT.Text = VAT.ToString("#,##0.00");
            labelVATable.Text = VATable.ToString("#,##0.00");
            labelDisTot.Text = sales.ToString("#,##0.00");
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            labelTime.Text = DateTime.Now.ToString("hh:mm:ss tt");
        }

        public void GetTransactionNo()
        {
            try
            {
                string date = DateTime.Now.ToString("yyyyMMdd");
                int count;
                string transactionno;
                connection.Open();
                command = new SqlCommand("SELECT TOP 1 transactionno FROM tbCart WHERE transactionno LIKE '" + date + "%' ORDER BY id desc", connection);
                dr = command.ExecuteReader();
                dr.Read();
                if (dr.HasRows)
                {
                    transactionno = dr[0].ToString();
                    count = int.Parse(transactionno.Substring(8, 4));
                    labelTransactionNo.Text = date + (count + 1);
                }
                else
                {
                    transactionno = date + "1001";
                    labelTransactionNo.Text = transactionno;
                }
                dr.Close();
                connection.Close();

            }
            catch (Exception ex)
            {
                connection.Close();
                MessageBox.Show(ex.Message, title);
            }


        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (MessageBox.Show("Exit Application?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void textBoxBar_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (textBoxBar.Text == string.Empty) return;
                else
                {

                    string prodcode;
                    double Price;
                    int quantity;
                    connection.Open();
                    command = new SqlCommand("SELECT  * FROM tbProduct WHERE barcode LIKE '" + textBoxBar.Text + "'", connection);
                    dr = command.ExecuteReader();
                    dr.Read();

                    if (dr.HasRows)
                    {
                        quantity = int.Parse(dr["qty"].ToString());

                        prodcode = dr["prodcode"].ToString();
                        Price = double.Parse(dr["price"].ToString());
                        quantity = int.Parse(textBoxQuantity.Text);

                        dr.Close();
                        connection.Close();
                        AddToCart(prodcode, Price, quantity);

                    }
                    dr.Close();
                    connection.Close();
                }
            }

            catch (Exception ex)
            {
                connection.Close();
                MessageBox.Show(ex.Message, title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        public void AddToCart(string prodcode, double Price, int quantity)
        {
            try
            {
                string id = "";
                int CartQuantity = 0;
                bool discovered = false;
                connection.Open();
                command = new SqlCommand("SELECT * FROM tbCart WHERE transactionno = @transactionno and prodcode = @prodcode", connection);
                command.Parameters.AddWithValue("@transactionno", labelTransactionNo.Text);
                command.Parameters.AddWithValue("@prodcode", prodcode);
                dr = command.ExecuteReader();
                dr.Read();

                if (dr.HasRows)
                {
                    id = dr["id"].ToString();
                    CartQuantity = int.Parse(dr["qty"].ToString());
                    discovered = true;
                }
                else discovered = false;
                dr.Close();
                connection.Close();

                if (discovered)
                {
                    if (quantity < (int.Parse(textBoxQuantity.Text) + CartQuantity))
                    {
                        MessageBox.Show("Incapable of proceeding. Remaining quantity on hand is" + quantity, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    connection.Open();
                    command = new SqlCommand("UPDATE tbCart SET qty = (qty + " + quantity + ")WHERE id = '" + id + "'", connection);
                    command.ExecuteNonQuery();
                    connection.Close();
                    textBoxBar.SelectionStart = 0;
                    textBoxBar.SelectionLength = textBoxBar.Text.Length;
                    LoadCart();
                }
                else
                {
                    if (quantity < (int.Parse(textBoxQuantity.Text) + CartQuantity))
                    {
                        MessageBox.Show("Incapable of proceeding. Remaining quantity on hand is" + quantity, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    connection.Open();
                    command = new SqlCommand("INSERT INTO tbCart(transactionno, prodcode, price, qty, date, cashier) VALUES(@transactionno, @prodcode, @price, @qty, @date, @cashier)", connection);
                    command.Parameters.AddWithValue("@transactionno", labelTransactionNo.Text);
                    command.Parameters.AddWithValue("@prodcode", prodcode);
                    command.Parameters.AddWithValue("@price", Price);
                    command.Parameters.AddWithValue("@qty", quantity);
                    command.Parameters.AddWithValue("@date", DateTime.Now);
                    command.Parameters.AddWithValue("@cashier", labelUserName.Text);
                    command.ExecuteNonQuery();
                    connection.Close();
                    LoadCart();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, title);
            }
        }

        private void dataGridViewCashier_SelectionChanged(object sender, EventArgs e)
        {
            int i = dataGridViewCashier.CurrentRow.Index;
            id = dataGridViewCashier[1, i].Value.ToString();
            price = dataGridViewCashier[7, i].Value.ToString();
        }

        private void dataGridViewCashier_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string ColumnName = dataGridViewCashier.Columns[e.ColumnIndex].Name;
           
            if (ColumnName == "Delete")
            {
                if (MessageBox.Show("Are you sure you want to remove this item?", "Remove item", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    dbcon.ExecuteNonQuery("DELETE FROM tbCart WHERE id LIKE '" + dataGridViewCashier.Rows[e.RowIndex].Cells[1].Value.ToString() + "'");                  
                    MessageBox.Show("Item has been successfully removed!", "Remove item", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadCart();
                }
            }
            else if (ColumnName == "colAdd")
            {
                int i = 0;
                connection.Open();
                command = new SqlCommand("SELECT SUM(qty) AS qty FROM tbProduct WHERE prodcode LIKE '" + dataGridViewCashier.Rows[e.RowIndex].Cells[2].Value.ToString() + "' GROUP BY prodcode", connection);
                i = int.Parse(command.ExecuteScalar().ToString());
                connection.Close();

                if (int.Parse(dataGridViewCashier.Rows[e.RowIndex].Cells[5].Value.ToString()) <i)
                {
                    dbcon.ExecuteNonQuery("UPDATE tbCart SET qty = qty + " + int.Parse(textBoxQuantity.Text) + "WHERE transactionno LIKE '" + labelTransactionNo.Text + "' AND prodcode LIKE '" + dataGridViewCashier.Rows[e.RowIndex].Cells[2].Value.ToString() + "'");
                    LoadCart();
                }
                else
                {
                    MessageBox.Show("Remaining quantity on hand is " + i + "!", "Out of Stock", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }
            else if (ColumnName == "colReduce")
            {
                int i = 0;
                connection.Open();
                command = new SqlCommand("SELECT SUM(qty) AS qty FROM tbCart WHERE prodcode LIKE '" + dataGridViewCashier.Rows[e.RowIndex].Cells[2].Value.ToString() + "' GROUP BY prodcode", connection);
                i = int.Parse(command.ExecuteScalar().ToString());
                connection.Close();
                if (i>1)
                {
                    dbcon.ExecuteNonQuery("UPDATE tbCart SET qty = qty - " + int.Parse(textBoxQuantity.Text) + "WHERE transactionno LIKE '" + labelTransactionNo.Text + "' AND prodcode LIKE '" + dataGridViewCashier.Rows[e.RowIndex].Cells[2].Value.ToString() + "'");
                    LoadCart();
                }
                else
                {
                    MessageBox.Show("Remaining quantity on cart is " + i + "!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }
                

            
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panelSlide_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void labelUserName_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBoxQuantity_TextChanged(object sender, EventArgs e)
        {

        }

        private void labelTime_Click(object sender, EventArgs e)
        {

        }

        private void labelVATable_Click(object sender, EventArgs e)
        {

        }

        private void labelVAT_Click(object sender, EventArgs e)
        {

        }

        private void labelDIS_Click(object sender, EventArgs e)
        {

        }

        private void labelST_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void labelDate_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void labelTransactionNo_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void labelDisTot_Click(object sender, EventArgs e)
        {

        }
    }
}
