﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS
{
    public partial class LoginForm : Form
    {
        SqlConnection connection = new SqlConnection();
        SqlCommand command = new SqlCommand();
        DatabaseC dbcon = new DatabaseC();
        SqlDataReader dr;
       public string PassWord = "";
        public bool IsActive;
        public LoginForm()
        {
            InitializeComponent();
            connection = new SqlConnection(dbcon.myConnection());
            metroTextBoxUserName.Focus();
        }

        private void Close_Click(object sender, EventArgs e)
        {
           if (MessageBox.Show("Are you sure you want to exit?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            string UserName = "", Name = "", Role = "";
            try
            {
                bool discovered;
                connection.Open();
                command = new SqlCommand("SELECT * FROM tbUser WHERE username = @username and password = @password", connection);
                command.Parameters.AddWithValue("@username", metroTextBoxUserName.Text);
                command.Parameters.AddWithValue("@password", metroTextBoxPassword.Text);
                dr = command.ExecuteReader();
                dr.Read();

                if (dr.HasRows)
                {
                    discovered = true;
                    UserName = dr["username"].ToString();
                    Name = dr["fullname"].ToString();
                    Role = dr["role"].ToString();
                    PassWord = dr["password"].ToString();
                    IsActive = bool.Parse(dr["active"].ToString());

                }
                else
                {
                    discovered = false;
                }
                dr.Close();
                connection.Close();

                if(discovered)
                {
                    if(!IsActive)
                    {
                        MessageBox.Show("Account is invalid! Unable to Login", "Invalid Account", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    if (Role == "Cashier")
                    {
                        MessageBox.Show("Welcome " + Name + "!", "ACCESS GRANTED!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        metroTextBoxUserName.Clear();
                        metroTextBoxPassword.Clear();
                        this.Hide();
                        CASHIER cashier = new CASHIER();
                        cashier.labelUserName.Text = UserName;
                        cashier.labelNameRole.Text = Name + " ! " + Role;
                        cashier.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("Welcome! " + Name + " ! ", "ACCESS GRANTED!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        metroTextBoxUserName.Clear();
                        metroTextBoxPassword.Clear();
                        this.Hide();
                        Form1 form = new Form1();
                        form.Username.Text = UserName;
                        form.labelLN.Text = Name;
                        form.ShowDialog();
                    }
                }
                else
                {
                    MessageBox.Show("Username and Password is invalid!", "ACCOUNT DENIED", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                connection.Close();
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void metroTextBoxPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                buttonLogin.PerformClick();
            }
        }
    }
}
