﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS
{
    public partial class STOCK : Form
    {

        SqlConnection connection = new SqlConnection();
        SqlCommand command = new SqlCommand();
        DatabaseC dbcon = new DatabaseC();
        SqlDataReader dr;
        string title = "Point of Sales";
        public STOCK()
        {
            InitializeComponent();
            connection = new SqlConnection(dbcon.myConnection());
            LoadSupplier();
            GetReferenceNumber();
        }

        public void GetReferenceNumber()
        {
            Random random = new Random();
            textBoxReference.Clear();
            textBoxReference.Text += random.Next();
        }

        public void LoadSupplier()
        {
            comboBoxSupplier.Items.Clear();
            comboBoxSupplier.DataSource = dbcon.getTable("SELECT * FROM tbSupplier");
            comboBoxSupplier.DisplayMember = "supplier";
        }

        public void LoadStockIn()
        {
            int i = 0; 
            dataGridViewStock.Rows.Clear();
            connection.Open();
            command = new SqlCommand("SELECT * FROM view_Stock WHERE referenceno LIKE '" + textBoxReference.Text + "' AND stat LIKE 'Pending'", connection);
            dr = command.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataGridViewStock.Rows.Add(i, dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(), dr[4].ToString(), dr[5].ToString(), dr[6].ToString(), dr[7].ToString());

            }
            dr.Close();
            connection.Close();
            
        }

        private void dataGridViewProduct_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBoxSupplier_SelectedIndexChanged(object sender, EventArgs e)
        {
            connection.Open();
            command = new SqlCommand("SELECT * FROM tbSupplier WHERE supplier LIKE '" + comboBoxSupplier.Text + "'", connection);
            dr = command.ExecuteReader();
            dr.Read();

            if (dr.HasRows)
            {
                labelID.Text = dr["id"].ToString();
                textBoxContactPerson.Text = dr["contactperson"].ToString();
                textBoxAddress.Text = dr["address"].ToString();
            }
            dr.Close();
            connection.Close();
        }

        private void comboBoxSupplier_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void linkLabelGenerate_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            GetReferenceNumber();
        }

        private void linkLabelProduct_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            PRODUCTSTOCK prodstock = new PRODUCTSTOCK(this);
            prodstock.ShowDialog();
        }

        private void Entry_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridViewStock.Rows.Count > 0)
                {
                    if (MessageBox.Show("Are you sure you want to save this record?", title, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        for(int i = 0; i<dataGridViewStock.Rows.Count; i++)
                        {
                            connection.Open();
                            command = new SqlCommand("UPDATE tbProduct SET qty = qty + " + int.Parse(dataGridViewStock.Rows[i].Cells[5].Value.ToString()) + "WHERE prodcode LIKE '" + dataGridViewStock.Rows[i].Cells[3].Value.ToString() + "'", connection);
                            command.ExecuteNonQuery();
                            connection.Close();

                            connection.Open();
                            command = new SqlCommand("UPDATE tb_Stock SET qty = qty + " + int.Parse(dataGridViewStock.Rows[i].Cells[5].Value.ToString()) + ", stat = 'Done' WHERE id LIKE '" + dataGridViewStock.Rows[i].Cells[1].Value.ToString() + "'", connection);
                            command.ExecuteNonQuery();
                            connection.Close();
                        }
                        Clear();
                        LoadStockIn();
                        
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        public void Clear()
        {
            textBoxReference.Clear();
            textBoxStockBy.Clear();
            dateTimePickerStockDate.Value = DateTime.Now;
        }

        private void dataGridViewStock_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string ColumnName = dataGridViewStock.Columns[e.ColumnIndex].Name;
            if (ColumnName == "Delete")
            {
                if (MessageBox.Show("Are you sure you want to remove this item?", title, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    connection.Open();
                    command = new SqlCommand("DELETE FROM tb_Stock WHERE id = '" + dataGridViewStock.Rows[e.RowIndex].Cells[1].Value.ToString() + "'", connection);
                    command.ExecuteNonQuery();
                    connection.Close();
                    MessageBox.Show("Item has been successfully removed!", title, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadStockIn();
                }
            }
        }
    }
}
