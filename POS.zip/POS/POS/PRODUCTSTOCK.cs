﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS
{
    public partial class PRODUCTSTOCK : Form
    {
        SqlConnection connection = new SqlConnection();
        SqlCommand command = new SqlCommand();
        DatabaseC dbcon = new DatabaseC();
        SqlDataReader dr;
        string title = "Point of Sales";
        STOCK stock;
        public PRODUCTSTOCK(STOCK st)
        {
            InitializeComponent();
            connection = new SqlConnection(dbcon.myConnection());
            LoadProduct();
            stock = st;
        }

        private void metroTextBoxSearch_Click(object sender, EventArgs e)
        {

        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        public void LoadProduct()
        {
            int i = 0;
            dataGridViewProduct.Rows.Clear();
            command = new SqlCommand("SELECT prodcode, proddesc, qty FROM tbProduct WHERE proddesc LIKE '%" + metroTextBoxSearch.Text + "%'", connection);
            connection.Open();
            dr = command.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataGridViewProduct.Rows.Add(i, dr[0].ToString(), dr[1].ToString(), dr[2].ToString());
            }
            dr.Close();
            connection.Close();
        }

        private void dataGridViewProduct_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string ColumnnName = dataGridViewProduct.Columns[e.ColumnIndex].Name;
            if (ColumnnName == "Select")
            {
                if (stock.textBoxStockBy.Text == string.Empty)
                {
                    MessageBox.Show("Please enter StockIn by name", title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    stock.textBoxStockBy.Focus();
                    this.Dispose();
                    
                }
                if (MessageBox.Show("Are you sure you want to add this item?", title, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    try
                    {
                        connection.Open();
                        command = new SqlCommand("INSERT INTO tb_Stock (referenceno, prodcode, date, stockin, supplierid) VALUES (@referenceno, @prodcode, @date, @stockin, @supplierid)", connection);
                        command.Parameters.AddWithValue("@referenceno", stock.textBoxReference.Text);
                        command.Parameters.AddWithValue("@prodcode", dataGridViewProduct.Rows[e.RowIndex].Cells[1].Value.ToString());
                        command.Parameters.AddWithValue("@date", stock.dateTimePickerStockDate.Value);
                        command.Parameters.AddWithValue("@stockin", stock.textBoxStockBy.Text);
                        command.Parameters.AddWithValue("@supplierid", stock.labelID.Text);
                        command.ExecuteNonQuery();
                        connection.Close();
                        stock.LoadStockIn();
                        MessageBox.Show("Item has been successfully added!", title, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, title);
                    }
                }
            }
        }

        private void metroTextBoxSearch_TextChanged(object sender, EventArgs e)
        {
            LoadProduct();
        }
    }
}
